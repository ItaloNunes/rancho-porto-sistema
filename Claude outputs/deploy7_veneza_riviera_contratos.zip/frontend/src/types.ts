export type LoteStatus = "disponivel" | "reservado" | "vendido";

export interface CondominioResumo {
  id: string;
  slug: string;
  nome: string;
  incorporadora?: string | null;
  cidade?: string | null;
  segmento?: string | null;
  descricao?: string | null;
  logo_url?: string | null;
  hero_image_url?: string | null;
  landing_page_url?: string | null;
  total_lotes: number;
  total_disponiveis: number;
}

export interface PlanoDecoracao {
  river?: number[][];
  lagoon?: { cx: number; cy: number; rx: number; ry: number };
  entranceRoad?: { x: number; y: number; w: number; h: number };
  roundabout1?: { cx: number; cy: number; r: number };
  roundabout2?: { cx: number; cy: number; r: number };
}

export interface Lote {
  id: string;
  condominio_id: string;
  quadra: string;
  lote_numero: number;
  identificador: string;
  tamanho_m2: number;
  valor_total?: number | null;
  entrada?: number | null;
  entrega?: number | null;
  parcela_mensal?: number | null;
  qtd_parcelas?: number | null;
  prazo_entrega_meses?: number | null;
  status: LoteStatus;
  poligono: number[][];
  /** Só true depois que um admin marcou os cantos do lote na ferramenta do
   * painel — até lá `poligono` é só um placeholder de grade (não representa
   * a forma real do lote na planta em imagem). */
  poligono_definido?: boolean;
  foto_url?: string | null;
  /** Características da tabela da construtora (posição esquina/sol/sombra,
   * etapa, "saldo só por financiamento bancário"...) — empreendimentos de 10/10. */
  detalhes?: string | null;
  /** Só para casas (Veneza): área construída, em m². */
  area_construida_m2?: number | null;
  /** Plano de tabela do Veneza (29/10): balões anuais e saldo por financiamento bancário. */
  qtd_baloes?: number | null;
  valor_balao?: number | null;
  financiamento?: number | null;
}

export interface QuadraZona {
  /** Presente quando o empreendimento tem quadras reais (ex.: Porto Franco): casa por igualdade com Lote.quadra. */
  quadra?: string | null;
  /** Presentes quando a zona representa uma faixa de números de lote (ex.: Rancho Texas). */
  lote_min?: number | null;
  lote_max?: number | null;
  /** Texto exibido no chip de filtro; se ausente, cai para "Quadra {quadra}". */
  label?: string | null;
  x: number;
  y: number;
  w: number;
  h: number;
}

// ---------------------------------------------------------------------------
// Painel gerencial (CRM): corretores (logins), clientes/leads, propostas e
// reservas. Só usado dentro de /painel (autenticado) — nunca no catálogo público.
// ---------------------------------------------------------------------------

export type Papel = "admin" | "corretor" | "developer";

/** 'developer' é uma conta admin "e mais um pouco" (só ela vê a aba
 * Atividade, ver PainelLayout.tsx/PainelAtividade.tsx) — mas em tudo que já
 * era admin-only antes dela existir, ela continua valendo como admin. Usar
 * isso em vez de comparar `papel === "admin"` direto em qualquer checagem
 * de permissão nova, senão essa conta perde acesso a admin-only por engano. */
export function temAcessoAdmin(papel?: Papel | null): boolean {
  return papel === "admin" || papel === "developer";
}

export interface Corretor {
  id: string;
  nome: string;
  usuario?: string | null;
  email?: string | null;
  telefone?: string | null;
  papel: Papel;
  ativo: boolean;
  /** true assim que o corretor troca a própria senha (POST /crm/me/senha) —
   * editar o telefone depois não sobrescreve mais a senha automaticamente
   * (ver PATCH /crm/corretores/{id} no backend). */
  senha_customizada?: boolean;
  /** Só vem preenchido na resposta de PATCH quando a senha acabou de ser
   * (re)sincronizada com o telefone — mesma ideia do `senha` de
   * CorretorCriado, abaixo. */
  senha?: string | null;
  /** CRECI e dados bancários -- usados pra preencher sozinhos a cláusula de
   * comissão do contrato do Porto Franco (ver documentos_gerados.py no
   * backend). Opcionais -- nem todo corretor mexe com esse empreendimento. */
  cpf_cnpj?: string | null;
  creci?: string | null;
  banco?: string | null;
  agencia?: string | null;
  conta?: string | null;
  /** Computado no backend (schemas.Corretor.perfil_completo) — false só
   * quando `papel === "corretor"` e falta algum dos campos acima (ou o
   * nome). Admin/developer sempre vêm com `true` (não precisam de CRECI
   * pra usar o painel). Usado por PainelLayout.tsx pra decidir se mostra a
   * tela obrigatória de "complete seu cadastro". */
  perfil_completo: boolean;
}

/** Resposta de POST /crm/corretores — só nessa hora a senha aparece em
 * texto puro, pro admin repassar pro corretor. */
export interface CorretorCriado extends Corretor {
  senha: string;
}

/** Resposta de POST /crm/login — login próprio (usuário + senha), sem
 * Supabase Auth. `access_token` é o JWT guardado em lib/token.ts e mandado
 * como `Authorization: Bearer` nas próximas chamadas. */
export interface LoginResposta {
  access_token: string;
  corretor: Corretor;
}

/** Uma linha do resultado de POST /crm/corretores/importar. */
export interface CorretorImportadoItem {
  nome: string;
  usuario: string;
  senha?: string | null;
  ativo: boolean;
  status: "criado" | "ja_existia" | "erro";
  erro?: string | null;
}

export interface Cliente {
  id: string;
  nome: string;
  telefone?: string | null;
  email?: string | null;
  cpf?: string | null;
  observacoes?: string | null;
  origem?: string | null;
  corretor_id?: string | null;
  created_at: string;
}

export type PropostaStatus =
  | "rascunho"
  | "aguardando_aprovacao"
  | "aprovada"
  | "enviada"
  | "aceita"
  | "recusada"
  | "cancelada";

export interface Proposta {
  id: string;
  /** Número curto e sequencial (exibido como "Nº 0001-v2") — rastreabilidade
   * humana, já que o id é um uuid. Atribuído pelo banco na criação, nunca
   * editável. Ver formatarNumeroProposta em lib/api.ts. */
  numero: number;
  /** Sobe em +1 a cada edição de verdade (ver PATCH /crm/propostas/{id}) —
   * um número junto com a versão deixa claro se um PDF/print em mãos de
   * alguém ainda é a versão vigente da proposta. */
  versao: number;
  /** Nº do contrato (sequência própria a partir do 91, 09/10) — dado na 1ª
   * emissão do contrato; null antes disso. Ver numeroContrato em lib/api.ts. */
  numero_contrato?: number | null;
  lote_id: string;
  cliente_id: string;
  corretor_id?: string | null;
  formulario_id?: string | null;
  valor_proposto: number;
  condicoes_pagamento?: string | null;
  status: PropostaStatus;
  documento_url?: string | null;
  observacoes?: string | null;
  /** Formulário completo (mesmos campos da Proposta de Compra/Venda em
   * papel) quando a proposta foi criada direto pelo corretor no painel, sem
   * passar pelo link de qualificação do cliente final — usado pelo PDF. */
  dados_qualificacao?: Partial<QualificacaoDados> | null;
  /** Preenchido pelo backend assim que todos os documentos obrigatórios desta
   * proposta estiverem anexados (mesma ideia do reservas.analise_prazo_em,
   * só que contado a partir daqui) — some de volta pra null se um documento
   * obrigatório for removido depois. Ver PropostaDocumentos.tsx. */
  documentos_completos_em?: string | null;
  created_at: string;
}

export interface PropostaDetalhe extends Proposta {
  lote?: Lote | null;
  /** Nome do empreendimento do lote (GET /crm/propostas, 10/10). */
  condominio_nome?: string | null;
  /** Rascunho sem documentos completos: quando a reserva vence e ele expira junto (26/10). */
  reserva_expira_em?: string | null;
  /** Proposta cancelada sozinha porque a reserva venceu sem os documentos (26/10). */
  expirou_em?: string | null;
  cliente?: Cliente | null;
  documentos: DocumentoProposta[];
}

/** Documento anexado direto numa proposta pelo corretor, no painel — pode
 * ser enviado a qualquer momento, mesmo depois da proposta já criada (ao
 * contrário de DocumentoQualificacao, que trava assim que o formulário de
 * qualificação é enviado). Ver PainelPropostas.tsx e routers/crm.py. */
export interface DocumentoProposta {
  id: string;
  proposta_id: string;
  tipo: DocumentoTipo;
  nome_arquivo: string;
  tamanho_bytes?: number | null;
  enviado_por?: string | null;
  enviado_em: string;
}

export type ReservaStatus =
  | "pendente"
  | "em_atendimento"
  | "aguardando_qualificacao"
  | "em_analise_financeira"
  | "confirmada"
  | "cancelada";

export interface Reserva {
  id: string;
  lote_id: string;
  nome?: string | null;
  contato?: string | null;
  cpf?: string | null;
  observacao?: string | null;
  status: ReservaStatus;
  cliente_id?: string | null;
  corretor_id?: string | null;
  /** Preenchido quando a reserva entra em "em_analise_financeira" (now + 72h) —
   * mesmo prazo do expira_em abaixo, só que contado a partir do envio do
   * formulário. É o número mostrado pro corretor em PainelReservas.tsx e
   * PainelQualificacoes.tsx enquanto o financeiro ainda não decidiu. */
  analise_prazo_em?: string | null;
  /** Prazo duro de 72h (ver migration 0018) — passou disso sem confirmar a
   * compra, o backend expira a reserva sozinho e libera o lote (ver
   * _expirar_vencidas no backend). */
  expira_em?: string | null;
  /** Preenchido quando essa reserva já gerou uma proposta (criada do zero
   * já linkada, ou via botão "Gerar proposta" em PainelReservas.tsx) — a
   * partir daí não dá mais pra gerar outra proposta pra mesma reserva. */
  proposta_id?: string | null;
  /** "Foto" do preço do lote no instante em que esta reserva nasceu (ver
   * migration 0025) — não muda se o preço do lote for reajustado depois.
   * null só em reserva criada antes desta coluna existir. */
  valor_total_congelado?: number | null;
  entrada_congelado?: number | null;
  entrega_congelado?: number | null;
  parcela_mensal_congelada?: number | null;
  qtd_parcelas_congelada?: number | null;
  prazo_entrega_meses_congelado?: number | null;
  created_at: string;
}

export interface ReservaComLote extends Reserva {
  lote?: Lote | null;
  // Nome do corretor responsável (junto de `created_at`, herdado de Reserva)
  // — mostrado na fila de Reservas (ver PainelReservas.tsx).
  corretor?: { nome: string } | null;
}

export interface LoteComCondominio extends Lote {
  condominio_nome: string;
  condominio_slug: string;
  /** false = empreendimento oculto (ainda não liberado); só o financeiro recebe esses lotes. */
  condominio_ativo?: boolean;
  // "Observação" com data/hora de uma proposta ainda aberta (rascunho ou
  // aguardando aprovação) pra esse lote — ver GET /crm/lotes. null quando
  // não tem nenhuma proposta pendente no momento.
  proposta_pendente_status?: string | null;
  proposta_pendente_desde?: string | null;
  // Ver migration 0025 / GET /crm/lotes. True só quando o lote já teve
  // alguma mudança de preço registrada — só aí existe pra onde "desfazer
  // última alteração" (ver PainelLotes.tsx).
  preco_pode_reverter?: boolean;
  preco_alterado_em?: string | null;
}

/** Uma linha do histórico de preço de um lote (ver migration 0025 e
 * GET /condominios/lotes/{id}/precos/historico) — mais recente primeiro. */
export interface LotePrecoHistorico {
  id: string;
  lote_id: string;
  valor_total?: number | null;
  entrada?: number | null;
  entrega?: number | null;
  parcela_mensal?: number | null;
  qtd_parcelas?: number | null;
  prazo_entrega_meses?: number | null;
  vigente_desde: string;
  vigente_ate?: string | null;
  origem: "sistema" | "reversao";
}

/** Uma linha do feed de Atividade (só developer, ver GET /crm/atividade e
 * PainelAtividade.tsx) — reserva/proposta/cliente criados recentemente. */
export interface AtividadeItem {
  tipo: "reserva" | "proposta" | "cliente";
  lote_identificador?: string | null;
  nome_pessoa?: string | null;
  valor_proposto?: number | null;
  status?: string | null;
  corretor_nome?: string | null;
  created_at: string;
}

/** Uma linha do log de auditoria completo (só developer, ver GET /crm/logs e
 * PainelLogs.tsx) — toda ação relevante do painel: quem fez, o quê, quando e
 * em qual registro. ator_* é uma foto de quando aconteceu (não muda se a
 * pessoa for renomeada/desativada depois); vem null só em ação automática
 * do próprio sistema (ex.: reserva expirando sozinha). */
export interface LogAuditoria {
  id: string;
  created_at: string;
  ator_id?: string | null;
  ator_nome?: string | null;
  ator_papel?: string | null;
  acao: string;
  entidade: string;
  entidade_id?: string | null;
  descricao: string;
  detalhes?: Record<string, unknown> | null;
}

export interface VisaoGeralCondominio {
  condominio_id: string;
  nome: string;
  slug: string;
  total_lotes: number;
  disponiveis: number;
  reservados: number;
  vendidos: number;
  valor_total_vendido: number;
  propostas_abertas: number;
  valor_em_propostas_abertas: number;
}

// ---------------------------------------------------------------------------
// Qualificação do cliente final: reserva -> link público -> formulário em
// etapas + documentos -> análise financeira manual -> aprova (gera proposta)
// ou reprova. Ver backend/app/routers/qualificacao.py.
// ---------------------------------------------------------------------------

export type QualificacaoStatus = "aguardando_preenchimento" | "em_analise" | "aprovada" | "reprovada";
export type EstadoCivil = "solteiro" | "casado" | "uniao_estavel" | "viuvo" | "divorciado" | "outros";
export type DocumentoTipo =
  | "rg"
  | "cpf"
  | "comprovante_residencia"
  | "certidao_nascimento_casamento"
  | "conjuge_rg"
  | "conjuge_cpf"
  | "comprovante_renda"
  // Comprovante de PIX/TED de um pagamento (entrada ou parcela) — só pode
  // ser anexado depois que a proposta já está aprovada (ver checagem em
  // backend/app/routers/crm.py::anexar_documento_proposta). Pedido em 28/09.
  | "comprovante_pagamento"
  | "outro";

export const DOCUMENTOS_OBRIGATORIOS: DocumentoTipo[] = [
  "rg",
  "cpf",
  "comprovante_residencia",
  "certidao_nascimento_casamento",
  "comprovante_renda",
];
export const DOCUMENTOS_CONJUGE: DocumentoTipo[] = ["conjuge_rg", "conjuge_cpf"];

export const DOCUMENTO_LABEL: Record<DocumentoTipo, string> = {
  rg: "RG",
  cpf: "CPF",
  comprovante_residencia: "Comprovante de residência",
  certidao_nascimento_casamento: "Certidão de nascimento ou casamento",
  conjuge_rg: "RG do cônjuge",
  conjuge_cpf: "CPF do cônjuge",
  comprovante_renda: "Comprovante de renda",
  comprovante_pagamento: "Comprovante de pagamento (PIX/TED)",
  outro: "Outro documento",
};

export interface EnderecoDados {
  rua?: string | null;
  numero?: string | null;
  complemento?: string | null;
  bairro?: string | null;
  cidade?: string | null;
  estado?: string | null;
  cep?: string | null;
}

export interface PessoaDados {
  nome?: string | null;
  rg?: string | null;
  orgao_expedidor?: string | null;
  cpf_cnpj?: string | null;
  data_nascimento?: string | null;
  nacionalidade?: string | null;
  email?: string | null;
  profissao?: string | null;
  /** Cidade/UF de nascimento — "LOCAL" do QUADRO RESUMO dos contratos. */
  naturalidade?: string | null;
}

export interface FormaPagamentoDados {
  a_vista?: boolean | null;
  renda?: string | null;
  valor_proposto?: number | null;
  sinal?: string | null;
  sinal_cheque_numero?: string | null;
  sinal_banco?: string | null;
  sinal_agencia?: string | null;
  dividido_em_parcelas?: number | null;
  valor_parcela?: string | null;
  vencimento?: string | null;
  primeiro_mes?: string | null;
  intercaladas_valor?: string | null;
  intercaladas_vencimento_dia?: string | null;
  observacoes?: string | null;
  // --- Plano estruturado (formulário de 02/10 — ver lib/pagamento.ts) ---
  avista_meio?: MeioPagamento | null;
  avista_data?: string | null; // AAAA-MM-DD
  sinal_forma?: "unica" | "parcelada" | null;
  sinal_parcelas?: number | null;
  sinal_valor_parcela?: string | null; // calculado pelo servidor
  sinal_meio?: MeioPagamento | null;
  sinal_vencimento?: string | null; // AAAA-MM-DD
  chave_valor?: string | null;
  chave_vencimento?: string | null; // AAAA-MM-DD
  /** Casas do Veneza (29/10): balões anuais e saldo por financiamento bancário. */
  balao_qtd?: number | null;
  balao_valor?: string | null;
  financiamento_valor?: string | null;
  /** Valor de tabela quando a proposta foi feita (gravado pelo servidor). */
  valor_tabela?: number | null;
  confirma_valor_fora_tabela?: boolean | null;
  confirmado?: boolean | null;
}

export type MeioPagamento = "pix" | "transferencia" | "boleto" | "cheque" | "dinheiro";

export type EnderecoCorrespondencia = "residencial" | "comercial";

export interface QualificacaoDados {
  proponente: PessoaDados;
  estado_civil?: EstadoCivil | null;
  /** "O comprador tem cônjuge ou companheiro(a) que assina junto?" (03/10).
   * Sem resposta (proposta antiga), vale o estado civil — ver temConjuge. */
  tem_conjuge?: boolean | null;
  conjuge?: PessoaDados | null;
  endereco_residencial: EnderecoDados;
  endereco_comercial: EnderecoDados;
  // Nem todo proponente tem endereço comercial próprio (autônomo, aposentado
  // etc.) — sem essa flag não dá pra distinguir "não preencheu ainda" de
  // "não se aplica" na validação do envio final.
  endereco_comercial_nao_possui?: boolean | null;
  // Pra qual dos dois endereços vai a correspondência — mesmo campo (X)
  // Residencial/Comercial do formulário em papel. Só relevante quando existe
  // endereço comercial; sem ele a correspondência é sempre a residencial.
  endereco_correspondencia?: EnderecoCorrespondencia | null;
  telefone_residencial?: string | null;
  telefone_comercial?: string | null;
  telefone_celular?: string | null;
  telefone_recados?: string | null;
  falar_com?: string | null;
  forma_pagamento: FormaPagamentoDados;
}

export function qualificacaoDadosVazio(): QualificacaoDados {
  return {
    proponente: {},
    estado_civil: null,
    conjuge: null,
    endereco_residencial: {},
    endereco_comercial: {},
    endereco_comercial_nao_possui: false,
    endereco_correspondencia: null,
    forma_pagamento: {},
  };
}

export interface DocumentoQualificacao {
  id: string;
  formulario_id: string;
  tipo: DocumentoTipo;
  nome_arquivo: string;
  tamanho_bytes?: number | null;
  enviado_em: string;
}

export interface Qualificacao {
  id: string;
  reserva_id: string;
  lote_id: string;
  cliente_id: string;
  corretor_id?: string | null;
  token: string;
  status: QualificacaoStatus;
  dados: Partial<QualificacaoDados>;
  enviado_em?: string | null;
  analisado_em?: string | null;
  analisado_por?: string | null;
  motivo_reprovacao?: string | null;
  created_at: string;
}

export interface QualificacaoComRelacoes extends Qualificacao {
  lote?: Lote | null;
  cliente?: Cliente | null;
  corretor?: Corretor | null;
  documentos: DocumentoQualificacao[];
}

export interface QualificacaoPublica {
  status: QualificacaoStatus;
  dados: Partial<QualificacaoDados>;
  documentos: DocumentoQualificacao[];
  lote_identificador: string;
  condominio_nome: string;
  motivo_reprovacao?: string | null;
}

export interface CondominioDetalhe extends CondominioResumo {
  plan_w?: number | null;
  plan_h?: number | null;
  plan_minx?: number | null;
  plan_miny?: number | null;
  plan_decor?: PlanoDecoracao | null;
  /** Quando preenchido, a planta é a imagem real (ver plan_quadras) em vez do modo polígono-por-lote. */
  plan_image_url?: string | null;
  /** Zonas clicáveis aproximadas por quadra — só usado quando plan_image_url está preenchido. */
  plan_quadras?: QuadraZona[] | null;
  base_precos_em?: string | null;
  lotes: Lote[];
}

// Importação de planilha de lotes (painel, só admin — ver
// pages/painel/PainelImportarPlanilha.tsx e lib/api.ts::importarLotesPreview/
// importarLotesConfirmar). Cobre venda/reserva feita fora do sistema.
export interface ImportacaoLinha {
  lote_id: string;
  quadra: string;
  lote_numero: number;
  identificador: string;
  status_atual: LoteStatus;
  status_planilha: LoteStatus;
  // Presente quando esse lote já tem uma reserva ou proposta ATIVA no
  // sistema — avisa antes de confirmar uma troca por cima de uma negociação
  // em andamento (ver PainelImportarPlanilha.tsx).
  pendencia_tipo?: "reserva" | "proposta" | null;
  pendencia_corretor?: string | null;
  pendencia_desde?: string | null;
}

/** Resposta de POST /condominios/lotes/importar/confirmar — `ignorados` é a
 * contagem de itens que não foram aplicados porque o lote mudou de status
 * entre a análise da planilha e a confirmação (ver
 * ImportacaoConfirmarItem.status_atual no backend). `bloqueados_por_pendencia`
 * é a contagem de itens recusados porque o lote tem reserva/proposta ATIVA
 * no sistema — o backend nunca aplica essa troca, mesmo que o item tenha
 * sido marcado na tela (ver PainelImportarPlanilha.tsx). */
export interface ImportacaoConfirmarResultado {
  atualizados: Lote[];
  ignorados: number;
  bloqueados_por_pendencia: number;
}

export interface ImportacaoPreview {
  condominio_id: string;
  condominio_nome: string;
  total_linhas_planilha: number;
  total_casadas: number;
  total_alteracoes: number;
  linhas: ImportacaoLinha[];
  nao_encontrados: string[];
}
