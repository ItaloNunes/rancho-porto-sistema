import re
from datetime import date, datetime
from typing import Literal, Optional

from pydantic import BaseModel, Field, computed_field, field_validator, model_validator

from .plano_pagamento import normalizar_valor_br
from .texto_seguro import limpar_nome

LoteStatus = Literal["disponivel", "reservado", "vendido"]
ReservaStatus = Literal[
    "pendente", "em_atendimento", "aguardando_qualificacao", "em_analise_financeira", "confirmada", "cancelada"
]

_EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")


def _valida_contato(v: str) -> str:
    """Aceita telefone (com DDD, 10 ou 11 dígitos) ou e-mail — o que vier no
    campo único "telefone ou e-mail" do formulário de reserva."""
    if "@" in v:
        if not _EMAIL_RE.match(v):
            raise ValueError("E-mail inválido.")
        return v
    digitos = re.sub(r"\D", "", v)
    if len(digitos) < 10 or len(digitos) > 11:
        raise ValueError("Telefone inválido — informe o DDD + número (10 ou 11 dígitos).")
    return v


class CondominioResumo(BaseModel):
    """Usado na tela de seleção (home): não carrega a lista de lotes."""

    id: str
    slug: str
    nome: str
    incorporadora: Optional[str] = None
    cidade: Optional[str] = None
    segmento: Optional[str] = None
    descricao: Optional[str] = None
    logo_url: Optional[str] = None
    hero_image_url: Optional[str] = None
    landing_page_url: Optional[str] = None
    total_lotes: int = 0
    total_disponiveis: int = 0


class PlanoDecoracao(BaseModel):
    river: list[list[float]] = Field(default_factory=list)
    lagoon: Optional[dict] = None
    entranceRoad: Optional[dict] = None
    roundabout1: Optional[dict] = None
    roundabout2: Optional[dict] = None


class QuadraZona(BaseModel):
    """Zona clicável aproximada usada no modo planta-em-imagem (ver
    CondominioDetalhe.plan_image_url). Coordenadas no mesmo espaço de plan_w/plan_h.

    Duas formas de casar a zona com os lotes da lista, dependendo do condomínio:
    - `quadra`: quando o empreendimento tem quadras reais (ex.: Porto Franco) — casa
      por igualdade com `Lote.quadra`.
    - `lote_min`/`lote_max`: quando não há agrupamento por quadra e a zona representa
      uma faixa de números de lote (ex.: Rancho Texas, onde cada lote é sua própria
      "quadra") — casa por `lote_min <= Lote.lote_numero <= lote_max`.
    `label`, quando presente, é o texto mostrado no lugar de "Quadra {quadra}".
    """

    quadra: Optional[str] = None
    lote_min: Optional[int] = None
    lote_max: Optional[int] = None
    label: Optional[str] = None
    x: float
    y: float
    w: float
    h: float


class Lote(BaseModel):
    id: str
    condominio_id: str
    quadra: str
    lote_numero: int
    identificador: str
    tamanho_m2: float
    valor_total: Optional[float] = None
    entrada: Optional[float] = None
    entrega: Optional[float] = None
    parcela_mensal: Optional[float] = None
    qtd_parcelas: Optional[int] = None
    prazo_entrega_meses: Optional[int] = None
    status: LoteStatus
    poligono: list[list[float]]
    # Só True depois que um admin marcou manualmente os cantos do lote sobre a
    # planta real, na ferramenta do painel — até lá, `poligono` é apenas um
    # placeholder de grade (ver migração 0008) e não deve ser desenhado como
    # a forma real do lote.
    poligono_definido: bool = False
    foto_url: Optional[str] = None
    # Empreendimentos novos (10/10): características que a tabela da
    # construtora traz e o sistema não tinha onde guardar -- posição do lote
    # (esquina/sol/sombra), casa só com financiamento bancário etc. -- e a
    # área construída, quando o imóvel é casa (Veneza).
    detalhes: Optional[str] = None
    area_construida_m2: Optional[float] = None
    # Plano de tabela das casas do Veneza (29/10, migration 0031): balões
    # anuais (quantidade e valor de cada) e o saldo por financiamento bancário.
    qtd_baloes: Optional[int] = None
    valor_balao: Optional[float] = None
    financiamento: Optional[float] = None


class CondominioDetalhe(CondominioResumo):
    plan_w: Optional[float] = None
    plan_h: Optional[float] = None
    plan_minx: Optional[float] = None
    plan_miny: Optional[float] = None
    plan_decor: Optional[PlanoDecoracao] = None
    plan_image_url: Optional[str] = None
    plan_quadras: Optional[list[QuadraZona]] = None
    base_precos_em: Optional[date] = None
    lotes: list[Lote] = Field(default_factory=list)


class LoteStatusUpdate(BaseModel):
    status: LoteStatus
    # Ver condominios.py::atualizar_status_lote — por padrão, a troca é
    # recusada (409) se o lote tiver reserva/proposta ATIVA no sistema.
    # `forcar=True` é o único jeito de passar por cima disso: exige uma
    # segunda confirmação explícita do admin no painel (não é o padrão do
    # select nem algo que aconteça sem essa etapa extra).
    forcar: bool = False


class ImportacaoLinha(BaseModel):
    """Uma linha da planilha importada cujo status difere do que está hoje no
    banco (ver POST /condominios/lotes/importar/preview) — só as diferenças
    aparecem aqui, não a planilha inteira."""

    lote_id: str
    quadra: str
    lote_numero: int
    identificador: str
    status_atual: LoteStatus
    status_planilha: LoteStatus
    # Preenchido quando esse lote já tem uma reserva ou proposta ATIVA no
    # sistema (alguém já está negociando ele por dentro do painel) — avisa o
    # admin antes de sobrescrever o status por cima dessa negociação em
    # andamento (ver preview_importacao_lotes). None quando o lote está livre
    # de qualquer pendência.
    pendencia_tipo: Optional[Literal["reserva", "proposta"]] = None
    pendencia_corretor: Optional[str] = None
    pendencia_desde: Optional[datetime] = None


class ImportacaoPreview(BaseModel):
    condominio_id: str
    condominio_nome: str
    total_linhas_planilha: int
    total_casadas: int
    total_alteracoes: int
    linhas: list[ImportacaoLinha]
    # Linhas da planilha (quadra/lote) que não bateram com nenhum lote do
    # empreendimento — normalmente erro de digitação na planilha do admin.
    nao_encontrados: list[str]


class ImportacaoConfirmarItem(BaseModel):
    lote_id: str
    status: LoteStatus
    # Status que a tela de preview mostrou pra esse lote no momento em que a
    # planilha foi analisada — o backend só aplica a troca se o lote AINDA
    # estiver nesse status no instante da confirmação (ver
    # confirmar_importacao_lotes). Protege contra a janela de tempo entre o
    # admin analisar a planilha e clicar em "Confirmar": se um corretor
    # reservou/vendeu o lote nesse meio tempo pelo fluxo normal, a importação
    # não sobrescreve essa mudança às cegas.
    status_atual: LoteStatus


class ImportacaoConfirmarPayload(BaseModel):
    """O front manda de volta só os itens que ficaram marcados na tela de
    preview — não reprocessa a planilha, evitando reler o arquivo (que já
    pode ter sido fechado/trocado do lado do admin) uma segunda vez."""

    itens: list[ImportacaoConfirmarItem]


class ImportacaoConfirmarResultado(BaseModel):
    """`ignorados` conta os itens cujo status mudou entre a análise da
    planilha e a confirmação (ver ImportacaoConfirmarItem.status_atual) — o
    front avisa o admin pra revisar esses lotes de novo, em vez de assumir
    que tudo que foi marcado na tela realmente foi aplicado.

    `bloqueados_por_pendencia` conta itens recusados porque o lote tem
    reserva/proposta ATIVA no sistema (ver confirmar_importacao_lotes /
    _pendencias_ativas) — o backend recusa esses incondicionalmente, mesmo
    que o front tenha mandado o item marcado. Esse campo já era emitido pelo
    endpoint antes de existir aqui no schema (por isso o valor sumia
    silenciosamente da resposta — pydantic descarta chave que o
    response_model não declara); agora fica visível pro front avisar o admin
    em vez de dar a entender que só `ignorados` pode zerar uma seleção."""

    atualizados: list[Lote]
    ignorados: int
    bloqueados_por_pendencia: int = 0


class LotePoligonoUpdate(BaseModel):
    """Marca manual dos cantos do lote sobre a planta real (ferramenta do
    painel, admin) — mesmo espaço de coordenadas de CondominioDetalhe
    (plan_w/plan_h/plan_minx/plan_miny). Lista vazia "desmarca" o lote (volta
    a cair no fallback de zona por quadra)."""

    poligono: list[list[float]]


class ReservaCreate(BaseModel):
    """Pedido de reserva feito pelo cliente no catálogo público — contato é
    obrigatório (telefone ou e-mail) pra evitar leads sem nenhum jeito de
    retorno; nome fica opcional.

    `cpf` existe pra suportar o fluxo novo (corretor loga, informa nome
    completo + CPF opcional + lote na hora de reservar, sem precisar de um
    Cadastro de Cliente separado) — nunca obrigatório."""

    nome: Optional[str] = None
    contato: str
    cpf: Optional[str] = None
    observacao: Optional[str] = None

    @field_validator("contato")
    @classmethod
    def _contato_obrigatorio(cls, v: str) -> str:
        v = (v or "").strip()
        if not v:
            raise ValueError("Informe um telefone ou e-mail para contato.")
        return _valida_contato(v)


class ReservaPublicaCreate(ReservaCreate):
    """Pedido vindo do formulário público (sem login) — carrega, além dos
    campos normais, dois sinais anti-spam que só fazem sentido nesse
    contexto (ver backend/app/antispam.py): um honeypot (`website`, campo
    escondido que só um bot preenche) e o instante em que o formulário foi
    carregado (`carregado_em`, epoch em ms — usado pra rejeitar envios rápidos
    demais pra terem sido digitados). Nenhum dos dois é salvo no banco."""

    website: Optional[str] = None
    carregado_em: Optional[int] = None


class ReservaCreateInterna(ReservaCreate):
    """Criação manual de um pedido pelo painel (corretor/admin) — diferente do
    pedido público (POST /lotes/{id}/reservar), aqui quem cria escolhe o lote
    e o contato pode ficar em branco por enquanto (é o formulário público que
    precisa garantir um jeito de retorno; internamente o corretor já sabe
    quem é o lead)."""

    lote_id: str
    contato: Optional[str] = None

    @field_validator("contato")
    @classmethod
    def _contato_opcional(cls, v: Optional[str]) -> Optional[str]:
        v = (v or "").strip() or None
        return _valida_contato(v) if v else v


class ReservaUpdate(BaseModel):
    """Edição dos dados do pedido (não do status — ver ReservaStatusUpdate).
    Contato aqui também é opcional (pode já estar preenchido, ou o corretor
    só quer corrigir o nome) — mas se vier preenchido, precisa ser válido."""

    nome: Optional[str] = None
    contato: Optional[str] = None
    cpf: Optional[str] = None
    observacao: Optional[str] = None

    @field_validator("contato")
    @classmethod
    def _contato_valido_se_preenchido(cls, v: Optional[str]) -> Optional[str]:
        v = (v or "").strip() or None
        return _valida_contato(v) if v else v


class Reserva(BaseModel):
    id: str
    lote_id: str
    nome: Optional[str] = None
    contato: Optional[str] = None
    cpf: Optional[str] = None
    observacao: Optional[str] = None
    status: ReservaStatus
    cliente_id: Optional[str] = None
    corretor_id: Optional[str] = None
    # Preenchido só quando a própria reserva nasceu sozinha, a partir da
    # aprovação de uma proposta (ver atualizar_status_proposta em
    # routers/crm.py) — None em toda reserva criada do jeito normal (link
    # público ou formulário do painel).
    proposta_id: Optional[str] = None
    analise_prazo_em: Optional[datetime] = None
    # Prazo duro de 24h — passou disso sem confirmar, a reserva expira
    # sozinha (ver _expirar_vencidas em routers/reservas.py). Só None em
    # reserva já 'confirmada'/'cancelada' criada antes desta regra existir.
    expira_em: Optional[datetime] = None
    # "Foto" do preço do lote no instante em que ESTA reserva nasceu (ver
    # criar_reserva em routers/reservas.py e migração 0025) — nunca
    # recalculado depois. Garante que um reajuste de preço no empreendimento,
    # feito depois que a negociação já começou, não muda o valor que valia
    # pra este cliente específico. None só em reserva criada antes desta
    # coluna existir.
    valor_total_congelado: Optional[float] = None
    entrada_congelado: Optional[float] = None
    entrega_congelado: Optional[float] = None
    parcela_mensal_congelada: Optional[float] = None
    qtd_parcelas_congelada: Optional[int] = None
    prazo_entrega_meses_congelado: Optional[int] = None
    created_at: datetime


class CorretorNome(BaseModel):
    """Recorte mínimo de Corretor (só o nome) pra embutir em listagens que só
    precisam mostrar "quem" — como a fila de Reservas (ver ReservaComLote) —
    sem expor usuário/telefone/papel à toa."""

    nome: str


class ReservaComLote(Reserva):
    lote: Optional[Lote] = None
    # Nome do corretor responsável pelo pedido — junto de `created_at`
    # (herdado de Reserva), dá pra fila de Reservas mostrar quem reservou
    # cada lote e desde quando, sem a pessoa precisar abrir/editar o pedido
    # pra descobrir.
    corretor: Optional[CorretorNome] = None


class ReservaStatusUpdate(BaseModel):
    status: ReservaStatus
    corretor_id: Optional[str] = None


class LoteComCondominio(Lote):
    """Lote com o nome/slug do condomínio embutido — usado só na listagem
    unificada do painel (ver GET /crm/lotes)."""

    condominio_nome: str
    condominio_slug: str
    condominio_ativo: bool = True
    # "Observação" com data/hora que a tela de Lotes mostra assim que um
    # corretor cria uma proposta (mesmo em rascunho) pra esse lote — avisa o
    # admin que tem gente em negociação antes mesmo de virar reserva. Vem só
    # de propostas ainda abertas (rascunho/aguardando_aprovacao); some
    # sozinho quando a proposta é aprovada (aí já virou reserva, ver
    # atualizar_status_proposta) ou é recusada/cancelada. Tipado como str
    # solto (não PropostaStatus) só porque esse Literal é definido mais
    # abaixo no arquivo, depois da seção de lotes.
    proposta_pendente_status: Optional[str] = None
    proposta_pendente_desde: Optional[datetime] = None
    # Ver lotes_precos_historico (migração 0025) / listar_todos_lotes em
    # crm.py. True só quando este lote já teve pelo menos UMA mudança de
    # preço registrada (então existe um valor anterior real pra oferecer
    # "desfazer última alteração" em PainelLotes.tsx) — lote no preço
    # original desde sempre não tem pra onde reverter.
    preco_pode_reverter: bool = False
    preco_alterado_em: Optional[datetime] = None


class LotePrecoHistorico(BaseModel):
    """Uma linha do histórico de preço de um lote (ver migração 0025 /
    trigger fn_registrar_historico_preco_lote) — registrado automaticamente
    toda vez que valor_total/entrada/entrega/parcela_mensal/qtd_parcelas/
    prazo_entrega_meses muda, não importa o caminho (planilha de reajuste,
    script manual direto no banco, ou uma futura edição pelo painel)."""

    id: str
    lote_id: str
    valor_total: Optional[float] = None
    entrada: Optional[float] = None
    entrega: Optional[float] = None
    parcela_mensal: Optional[float] = None
    qtd_parcelas: Optional[int] = None
    prazo_entrega_meses: Optional[int] = None
    vigente_desde: datetime
    vigente_ate: Optional[datetime] = None
    origem: str


# ---------------------------------------------------------------------------
# Campos do formulário completo (RG, endereços, cônjuge, forma de pagamento
# detalhada etc.) — mesmos da Proposta de Compra/Venda em papel. Usado tanto
# pelo formulário público de qualificação (dados guardados em
# formularios_qualificacao.dados, ver mais abaixo) quanto por
# PropostaCreate.dados_qualificacao (formulário completo preenchido direto
# pelo corretor no painel, sem link de qualificação — daí precisar estar
# definido antes do bloco de CRM/propostas, logo abaixo).
# ---------------------------------------------------------------------------

EstadoCivil = Literal["solteiro", "casado", "uniao_estavel", "viuvo", "divorciado", "outros"]


class EnderecoDados(BaseModel):
    rua: Optional[str] = None
    numero: Optional[str] = None
    complemento: Optional[str] = None
    bairro: Optional[str] = None
    cidade: Optional[str] = None
    estado: Optional[str] = None
    cep: Optional[str] = None


class PessoaDados(BaseModel):
    """Campos de identificação — usado tanto para o proponente quanto (se
    casado) para o cônjuge, igual ao formulário em papel."""

    nome: Optional[str] = None
    rg: Optional[str] = None
    orgao_expedidor: Optional[str] = None
    cpf_cnpj: Optional[str] = None
    data_nascimento: Optional[str] = None
    nacionalidade: Optional[str] = None
    email: Optional[str] = None
    profissao: Optional[str] = None
    # Cidade/UF de nascimento -- vai no "LOCAL" do QUADRO RESUMO dos
    # contratos (pedido de 03/10).
    naturalidade: Optional[str] = None

    @field_validator("nome")
    @classmethod
    def _limpa_nome(cls, v: Optional[str]) -> Optional[str]:
        # letra estilizada / espaço invisível colado do WhatsApp sumia do
        # contrato (29/10) -- grava sempre o nome em letra normal
        return (limpar_nome(v) or None) if v is not None else None


_VALOR_INVALIDO_MSG = "Informe um valor numérico válido (ex.: 5000 ou 5000,00), sem letras ou símbolos."


def _parse_valor_monetario(v: Optional[str]) -> Optional[str]:
    """Aceita "5000", "5000.00", "5000,00" ou "R$ 5.000,00" — o que o campo já
    aceitava antes, mais o que os novos inputs numéricos do formulário mandam
    — e barra qualquer coisa que não seja um valor numérico de verdade. É
    exatamente esse tipo de erro de digitação (texto solto, letra junto do
    número, valor negativo) que motivou essa validação (pedido em 28/09).
    Continua guardando como string (não muda o tipo do campo, pra não quebrar
    a leitura de propostas antigas já salvas) — só garante que o que for
    salvo DAQUI PRA FRENTE é sempre um número válido."""
    if v is None:
        return v
    texto = v.strip()
    if not texto:
        return None
    limpo = normalizar_valor_br(texto)
    try:
        numero = float(limpo)
    except ValueError:
        raise ValueError(_VALOR_INVALIDO_MSG) from None
    if numero < 0:
        raise ValueError("O valor não pode ser negativo.")
    return texto


MeioPagamento = Literal["pix", "transferencia", "boleto", "cheque", "dinheiro"]


class FormaPagamentoDados(BaseModel):
    a_vista: Optional[bool] = None
    renda: Optional[str] = None
    # gt=0: valor proposto zerado ou negativo é sempre erro de digitação, não
    # um caso de negócio real (pedido de validação em 28/09).
    valor_proposto: Optional[float] = Field(default=None, gt=0)
    sinal: Optional[str] = None
    sinal_cheque_numero: Optional[str] = None
    sinal_banco: Optional[str] = None
    sinal_agencia: Optional[str] = None
    # ge=1: "0 parcelas" ou negativo não existe — se dividiu, é pelo menos 1.
    dividido_em_parcelas: Optional[int] = Field(default=None, ge=1)
    valor_parcela: Optional[str] = None
    vencimento: Optional[str] = None
    primeiro_mes: Optional[str] = None
    intercaladas_valor: Optional[str] = None
    intercaladas_vencimento_dia: Optional[str] = None
    observacoes: Optional[str] = None
    # --- Plano estruturado (formulário novo, 02/10 -- ver app/plano_pagamento.py)
    # À vista: como e quando paga.
    avista_meio: Optional[MeioPagamento] = None
    avista_data: Optional[str] = None  # AAAA-MM-DD
    # Entrada (sinal/arras) -- obrigatória no parcelado.
    sinal_forma: Optional[Literal["unica", "parcelada"]] = None
    sinal_parcelas: Optional[int] = Field(default=None, ge=1, le=24)
    sinal_valor_parcela: Optional[str] = None  # calculado pelo servidor
    sinal_meio: Optional[MeioPagamento] = None
    sinal_vencimento: Optional[str] = None  # AAAA-MM-DD (pagamento único ou 1ª parcela da entrada)
    # Chave (parcela paga na entrega) -- vem do plano de tabela do lote.
    chave_valor: Optional[str] = None
    chave_vencimento: Optional[str] = None  # AAAA-MM-DD, opcional
    # Casas do Veneza (29/10): balões anuais e saldo por financiamento bancário.
    balao_qtd: Optional[int] = Field(default=None, ge=0, le=20)
    balao_valor: Optional[str] = None
    financiamento_valor: Optional[str] = None
    # Valor de tabela do lote quando a proposta foi feita -- gravado pelo
    # servidor; é a base do "bônus" (desconto) no contrato do Veneza.
    valor_tabela: Optional[float] = None
    # Dupla confirmação do corretor (checkboxes da etapa de revisão).
    confirma_valor_fora_tabela: Optional[bool] = None
    confirmado: Optional[bool] = None

    @field_validator("sinal", "valor_parcela", "intercaladas_valor", "chave_valor", "balao_valor", "financiamento_valor")
    @classmethod
    def _valida_valor_monetario(cls, v: Optional[str]) -> Optional[str]:
        return _parse_valor_monetario(v)

    @model_validator(mode="after")
    def _valida_parcelamento(self) -> "FormaPagamentoDados":
        # Só faz sentido cobrar consistência de parcelas quando o pagamento
        # já foi declarado como parcelado — "à vista" (ou ainda não
        # respondido) não tem parcela nenhuma pra validar.
        if self.a_vista is False:
            tem_qtd = self.dividido_em_parcelas is not None
            tem_valor = bool(self.valor_parcela)
            if tem_qtd != tem_valor:
                raise ValueError(
                    "Pagamento parcelado precisa do número de parcelas e do valor de cada parcela, os dois juntos."
                )
        return self


class QualificacaoDados(BaseModel):
    """Corpo completo do formulário (mesmos campos da Proposta de
    Compra/Venda em papel) — guardado como JSON, seja em
    `formularios_qualificacao.dados` (preenchido pelo cliente final via link
    público) ou em `propostas.dados_qualificacao` (preenchido direto pelo
    corretor no painel). Tudo opcional no schema porque pode ser salvo
    parcialmente entre etapas; a validação de "está completo o bastante"
    é feita à parte, em cada fluxo (ver qualificacao.py e routers/crm.py)."""

    proponente: PessoaDados = Field(default_factory=PessoaDados)
    estado_civil: Optional[EstadoCivil] = None
    # Resposta direta do corretor (03/10): "o comprador tem cônjuge ou
    # companheiro(a) que assina junto?". True exige estado civil casado ou
    # união estável e os dados do cônjuge; ver cadastro_proposta.tem_conjuge.
    tem_conjuge: Optional[bool] = None
    conjuge: Optional[PessoaDados] = None
    endereco_residencial: EnderecoDados = Field(default_factory=EnderecoDados)
    endereco_comercial: EnderecoDados = Field(default_factory=EnderecoDados)
    # Nem todo proponente tem endereço comercial próprio (autônomo, aposentado
    # etc.) — sem essa flag não dá pra distinguir "não preencheu ainda" de
    # "não se aplica" na validação do envio final (ver enviar_para_analise).
    endereco_comercial_nao_possui: Optional[bool] = None
    # Pra qual dos dois endereços vai a correspondência — mesmo campo
    # "Comercial ( ) / Residencial ( )" da lateral do formulário em papel.
    endereco_correspondencia: Optional[Literal["residencial", "comercial"]] = None
    telefone_residencial: Optional[str] = None
    telefone_comercial: Optional[str] = None
    telefone_celular: Optional[str] = None
    telefone_recados: Optional[str] = None
    falar_com: Optional[str] = None
    forma_pagamento: FormaPagamentoDados = Field(default_factory=FormaPagamentoDados)


# ---------------------------------------------------------------------------
# CRM: clientes/leads, corretores e propostas de compra e venda.
# ---------------------------------------------------------------------------

PropostaStatus = Literal[
    "rascunho", "aguardando_aprovacao", "aprovada", "enviada", "aceita", "recusada", "cancelada"
]


class ClienteCreate(BaseModel):
    nome: str
    telefone: Optional[str] = None
    email: Optional[str] = None
    cpf: Optional[str] = None
    observacoes: Optional[str] = None
    origem: Optional[str] = None
    corretor_id: Optional[str] = None

    @field_validator("nome")
    @classmethod
    def _limpa_nome(cls, v: str) -> str:
        return limpar_nome(v) or v


class ClienteUpdate(BaseModel):
    """Todos os campos opcionais: só entra na atualização o que vier preenchido."""

    nome: Optional[str] = None
    telefone: Optional[str] = None
    email: Optional[str] = None
    cpf: Optional[str] = None
    observacoes: Optional[str] = None
    origem: Optional[str] = None
    corretor_id: Optional[str] = None

    @field_validator("nome")
    @classmethod
    def _limpa_nome(cls, v: Optional[str]) -> Optional[str]:
        return (limpar_nome(v) or v) if v is not None else None


class Cliente(ClienteCreate):
    id: str
    created_at: datetime


# "developer" é uma conta admin "e mais um pouco" — só ela vê a tela de
# Atividade (ver routers/crm.py::listar_atividade e security.py::eh_admin/
# require_developer). Não é escolhível em nenhum formulário do painel (ver
# criar_corretor/atualizar_corretor) — só setada direto no banco, de
# propósito, pra continuar sendo "só pra mim" mesmo com o código aberto.
Papel = Literal["admin", "corretor", "developer"]


class CorretorCreate(BaseModel):
    """Login por usuário (não mais convite por e-mail — ver
    routers/crm.py::criar_corretor e app/usuarios.py). `telefone` é
    obrigatório porque vira a senha inicial (só os dígitos); `usuario` é
    opcional — se não vier, é gerado a partir do nome (nome.sobrenome)."""

    nome: str
    telefone: str
    usuario: Optional[str] = None
    papel: Papel = "corretor"
    # CRECI e dados bancários -- preenchem sozinhos a cláusula de comissão do
    # contrato do Porto Franco (ver documentos_gerados.py). Opcionais aqui
    # porque o cadastro nasce só com login; costumam ser preenchidos depois,
    # na edição. Pedido em 28/09.
    cpf_cnpj: Optional[str] = None
    creci: Optional[str] = None
    banco: Optional[str] = None
    agencia: Optional[str] = None
    conta: Optional[str] = None


class CorretorUpdate(BaseModel):
    nome: Optional[str] = None
    telefone: Optional[str] = None
    papel: Optional[Papel] = None
    ativo: Optional[bool] = None
    # Força a senha de login de volta pro telefone atual, mesmo que o
    # corretor já tenha trocado a própria senha (senha_customizada=True) —
    # via manual do admin pra destravar quem esqueceu a senha. Ver
    # atualizar_corretor em routers/crm.py.
    resetar_senha: Optional[bool] = None
    cpf_cnpj: Optional[str] = None
    creci: Optional[str] = None
    banco: Optional[str] = None
    agencia: Optional[str] = None
    conta: Optional[str] = None


# Campos que fecham a tela obrigatória de "complete seu cadastro" (ver
# PainelLayout.tsx/GateCompletarCadastro) -- pedido em 28/09: sem isso, a
# cláusula de comissão do contrato do Porto Franco sai sem qualificar o
# corretor (só o nome, sem CPF/CRECI/dados bancários). Um lugar só pra essa
# lista, reaproveitada pelo validador de CorretorAutoUpdate (abaixo) e pelo
# computed_field Corretor.perfil_completo -- não dá pra desalinhar as duas
# checagens (uma decide se o PATCH é aceito, a outra decide se a tela de
# bloqueio unlock no front) se ambas olharem pra mesma tupla.
CAMPOS_CADASTRO_OBRIGATORIOS = ("nome", "cpf_cnpj", "creci", "banco", "agencia", "conta")


class CorretorAutoUpdate(BaseModel):
    """Body de PATCH /crm/me -- o próprio corretor logado completa o
    cadastro (nome completo + os dados que o contrato do Porto Franco
    exige). Diferente de CorretorUpdate (só admin): não aceita `papel`,
    `ativo` nem `resetar_senha` -- ninguém promove a si mesmo ou reativa a
    própria conta por aqui. Todos os campos são obrigatórios (não
    Optional) porque esse endpoint só existe pra fechar a tela de "complete
    seu cadastro" -- salvar pela metade não tiraria ninguém de lá mesmo,
    então é melhor recusar de cara do que devolver 200 e a pessoa continuar
    presa na mesma tela sem entender por quê. Pedido em 28/09."""

    nome: str
    cpf_cnpj: str
    creci: str
    banco: str
    agencia: str
    conta: str

    @field_validator(*CAMPOS_CADASTRO_OBRIGATORIOS)
    @classmethod
    def _nao_vazio(cls, v: str) -> str:
        v = v.strip()
        if not v:
            raise ValueError("Preencha todos os campos antes de salvar.")
        return v


class Corretor(BaseModel):
    id: str
    nome: str
    usuario: Optional[str] = None
    email: Optional[str] = None
    telefone: Optional[str] = None
    papel: Papel = "corretor"
    ativo: bool = True
    # True assim que o corretor troca a própria senha (POST /crm/me/senha)
    # — impede que uma correção de telefone sobrescreva sem avisar uma
    # senha que a pessoa escolheu.
    senha_customizada: bool = False
    # Só vem preenchido na resposta de PATCH /crm/corretores/{id} quando a
    # senha acabou de ser (re)sincronizada com o telefone — mesma ideia do
    # `senha` de CorretorCriado: única vez que aparece em texto puro.
    senha: Optional[str] = None
    cpf_cnpj: Optional[str] = None
    creci: Optional[str] = None
    banco: Optional[str] = None
    agencia: Optional[str] = None
    conta: Optional[str] = None

    @computed_field  # type: ignore[prop-decorator]
    @property
    def perfil_completo(self) -> bool:
        """Só corretor de verdade (papel="corretor") é obrigado a preencher
        esses dados -- admin/developer usam o painel pra gerir o sistema,
        não pra vender lote com o próprio nome na cláusula de comissão, e
        travar essas contas nessa tela não faria sentido (ver
        PainelLayout.tsx/GateCompletarCadastro, que lê este campo direto em
        vez de reimplementar a checagem no front). Pedido em 28/09."""
        if self.papel != "corretor":
            return True
        return all((getattr(self, campo) or "").strip() for campo in CAMPOS_CADASTRO_OBRIGATORIOS)


class CorretorCriado(Corretor):
    """Resposta de POST /crm/corretores — a única vez que a senha inicial
    (texto puro) aparece em algum lugar, pro admin poder repassar pro
    corretor. Depois disso ninguém mais consegue ver essa senha (o Supabase
    Auth só guarda o hash)."""

    senha: str


class LoginRequest(BaseModel):
    """Body de POST /crm/login — login próprio, sem Supabase Auth (ver
    app/security.py e app/usuarios.py)."""

    usuario: str
    senha: str


class LoginResponse(BaseModel):
    """Resposta de POST /crm/login — o front guarda `access_token` (JWT) e
    manda ele em `Authorization: Bearer` nas próximas chamadas."""

    access_token: str
    corretor: Corretor


class TrocarSenhaRequest(BaseModel):
    """Body de POST /crm/me/senha — o próprio corretor logado troca a
    senha, precisa confirmar a atual (evita que alguém que ache uma sessão
    aberta troque a senha sem saber a antiga)."""

    senha_atual: str
    senha_nova: str


class CorretorImportadoItem(BaseModel):
    """Uma linha do resultado de POST /crm/corretores/importar."""

    nome: str
    usuario: str
    senha: Optional[str] = None
    ativo: bool
    status: Literal["criado", "ja_existia", "erro"]
    erro: Optional[str] = None


class PropostaCreate(BaseModel):
    lote_id: str
    cliente_id: str
    corretor_id: Optional[str] = None
    valor_proposto: float
    condicoes_pagamento: Optional[str] = None
    observacoes: Optional[str] = None
    # Formulário completo (RG, endereços, cônjuge, forma de pagamento
    # detalhada etc.) — preenchido quando o corretor cria a proposta com o
    # formulário completo direto no painel (PropostaFormularioCompleto.tsx),
    # sem passar pelo link de qualificação do cliente final. Mesmo formato
    # de formularios_qualificacao.dados — usado por gerar_proposta_pdf.
    dados_qualificacao: Optional[QualificacaoDados] = None
    # Preenchido quando a proposta nasce "a partir de uma reserva" já
    # existente (botão "Gerar proposta" na fila de Reservas, ver
    # PainelReservas.tsx) — nesse caminho o lote já está travado pela
    # própria reserva, então criar_proposta pula a trava atômica normal
    # (que exige o lote 'disponivel') e só linka a proposta nova de volta
    # na reserva (reservas.proposta_id), em vez de gerar uma segunda
    # reserva duplicada (ver routers/crm.py::criar_proposta).
    reserva_id: Optional[str] = None


class PropostaDadosFinanceiro(BaseModel):
    """Body de PUT /crm/propostas/{id}/dados -- o financeiro (admin) corrige
    os dados da proposta antes de aprovar/gerar o contrato: comprador,
    cônjuge, endereços, contatos e a forma de pagamento inteira (o valor
    proposto vem dentro de forma_pagamento.valor_proposto, igual na criação).
    Passa pelas mesmas conferências da criação (ver routers/crm.py::
    editar_dados_proposta)."""

    dados_qualificacao: QualificacaoDados
    # Por que mudou (opcional) -- vai pro log de auditoria junto com o
    # antes/depois de cada campo alterado.
    motivo: Optional[str] = Field(default=None, max_length=500)


class PropostaStatusUpdate(BaseModel):
    status: PropostaStatus


class PropostaUpdate(BaseModel):
    """Edição dos dados da proposta (não do status — ver PropostaStatusUpdate)."""

    valor_proposto: Optional[float] = None
    condicoes_pagamento: Optional[str] = None
    observacoes: Optional[str] = None


class Proposta(BaseModel):
    id: str
    # Número curto e sequencial (Nº 0001, 0002...) — rastreabilidade humana,
    # já que o id é um uuid ilegível. Atribuído sozinho pelo banco na criação
    # (default nextval, ver migration 0020) — nunca mandado pelo cliente.
    numero: int
    # Sobe em +1 a cada PATCH /crm/propostas/{id} que muda algo de fato (ver
    # atualizar_proposta) — ajuda a saber, olhando só o número, se aquela
    # proposta em mãos é a versão mais recente ou uma cópia desatualizada.
    versao: int
    lote_id: str
    cliente_id: str
    corretor_id: Optional[str] = None
    formulario_id: Optional[str] = None
    valor_proposto: float
    condicoes_pagamento: Optional[str] = None
    status: PropostaStatus
    documento_url: Optional[str] = None
    observacoes: Optional[str] = None
    dados_qualificacao: Optional[dict] = None
    # Preenchido pelo backend (nunca pelo cliente) assim que todos os
    # documentos obrigatórios desta proposta estiverem anexados — mesma ideia
    # do reservas.analise_prazo_em, só que contado a partir daqui em vez do
    # envio do formulário de qualificação (ver migration 0021 e
    # routers/crm.py::_atualizar_documentos_completos_em). Some de volta pra
    # None se um documento obrigatório for removido depois.
    documentos_completos_em: Optional[datetime] = None
    created_at: datetime


class PropostaDetalhe(Proposta):
    lote: Optional[Lote] = None
    cliente: Optional[Cliente] = None
    condominio_nome: Optional[str] = None
    # Prazo da reserva da proposta ainda em rascunho (26/10): quando vence
    # sem os documentos completos, o rascunho expira junto (ver
    # reservas._expirar_vencidas) -- o corretor precisa ver isso na lista.
    reserva_expira_em: Optional[str] = None
    # Quando a proposta foi cancelada sozinha por esse prazo (log
    # 'proposta_expirou'); None = não expirou (ou foi cancelada à mão).
    expirou_em: Optional[str] = None
    # Forward ref (classe "DocumentoProposta" só é definida mais abaixo,
    # depois de DocumentoTipo) — mesmo padrão já usado por
    # QualificacaoComRelacoes.documentos logo abaixo neste arquivo.
    documentos: list["DocumentoProposta"] = Field(default_factory=list)


# ---------------------------------------------------------------------------
# Visão geral (painel gerencial, só admin): números consolidados por
# empreendimento — pra dashboard e pro relatório em PDF.
# ---------------------------------------------------------------------------


class AtividadeItem(BaseModel):
    """Uma linha do feed de Atividade (só developer, ver
    routers/crm.py::listar_atividade e security.py::require_developer) —
    reserva/proposta/cliente criados recentemente, com quem fez e quando.
    Baseado só em created_at (visão rápida de "o que é novo"; pra ver TODA
    ação — cancelamentos, edições, mudanças de status etc. — ver LogAuditoria
    /crm/logs, abaixo)."""

    tipo: Literal["reserva", "proposta", "cliente"]
    lote_identificador: Optional[str] = None
    nome_pessoa: Optional[str] = None
    valor_proposto: Optional[float] = None
    status: Optional[str] = None
    corretor_nome: Optional[str] = None
    created_at: datetime


class LogAuditoria(BaseModel):
    """Uma linha do log de auditoria (só developer, ver
    routers/crm.py::listar_logs, security.py::require_developer e
    app/auditoria.py::registrar_log) — toda ação relevante do painel: quem
    (ator_nome/ator_papel — foto de quando aconteceu, não muda se a pessoa
    for renomeada depois), o quê (acao/descricao), em qual registro
    (entidade/entidade_id) e quando (created_at). ator_* vem null só nas
    ações automáticas do próprio sistema (ex.: reserva expirando sozinha)."""

    id: str
    created_at: datetime
    ator_id: Optional[str] = None
    ator_nome: Optional[str] = None
    ator_papel: Optional[str] = None
    acao: str
    entidade: str
    entidade_id: Optional[str] = None
    descricao: str
    detalhes: Optional[dict] = None


class VisaoGeralCondominio(BaseModel):
    condominio_id: str
    nome: str
    slug: str
    total_lotes: int
    disponiveis: int
    reservados: int
    vendidos: int
    valor_total_vendido: float
    propostas_abertas: int
    valor_em_propostas_abertas: float


# ---------------------------------------------------------------------------
# Qualificação do cliente: o corretor reserva o lote, cadastra o cliente com
# o mínimo (nome/telefone/CPF) e gera um link público. O cliente final
# preenche, sem login, os mesmos campos da Proposta de Compra/Venda em papel
# e anexa os documentos exigidos. Vai pra análise financeira manual no
# painel — aprovado já gera a proposta.
# ---------------------------------------------------------------------------

QualificacaoStatus = Literal["aguardando_preenchimento", "em_analise", "aprovada", "reprovada"]
DocumentoTipo = Literal[
    "rg", "cpf", "comprovante_residencia", "certidao_nascimento_casamento",
    "conjuge_rg", "conjuge_cpf", "comprovante_renda",
    # Comprovante de PIX/TED de um pagamento (entrada ou parcela) — só pode
    # ser anexado depois que a proposta já está aprovada (ver checagem em
    # routers/crm.py::anexar_documento_proposta) e nunca conta como
    # obrigatório pra completar a qualificação. Pedido em 28/09.
    "comprovante_pagamento",
    "outro",
]

DOCUMENTOS_OBRIGATORIOS: tuple[DocumentoTipo, ...] = (
    "rg", "cpf", "comprovante_residencia", "certidao_nascimento_casamento", "comprovante_renda",
)
# Exigidos só quando estado_civil == "casado" (ver _valida_documentos_obrigatorios em qualificacao.py).
DOCUMENTOS_CONJUGE: tuple[DocumentoTipo, ...] = ("conjuge_rg", "conjuge_cpf")

# EstadoCivil, EnderecoDados, PessoaDados, FormaPagamentoDados e
# QualificacaoDados moraram aqui antes — subiram pra antes do bloco de CRM
# (ver acima de PropostaStatus) porque PropostaCreate.dados_qualificacao
# (formulário completo preenchido direto pelo corretor no painel, sem link
# de qualificação) passou a referenciar QualificacaoDados também.


class QualificacaoCreate(BaseModel):
    """O corretor gera o link a partir de uma reserva existente — escolhendo
    um cliente já cadastrado ou cadastrando um novo ali mesmo (mínimo:
    nome/telefone/CPF)."""

    cliente_id: Optional[str] = None
    cliente_novo: Optional[ClienteCreate] = None


class Qualificacao(BaseModel):
    id: str
    reserva_id: str
    lote_id: str
    cliente_id: str
    corretor_id: Optional[str] = None
    token: str
    status: QualificacaoStatus
    dados: dict = Field(default_factory=dict)
    enviado_em: Optional[datetime] = None
    analisado_em: Optional[datetime] = None
    analisado_por: Optional[str] = None
    motivo_reprovacao: Optional[str] = None
    created_at: datetime


class QualificacaoComRelacoes(Qualificacao):
    lote: Optional[Lote] = None
    cliente: Optional[Cliente] = None
    corretor: Optional[Corretor] = None
    documentos: list["DocumentoQualificacao"] = Field(default_factory=list)


class DocumentoQualificacao(BaseModel):
    id: str
    formulario_id: str
    tipo: DocumentoTipo
    nome_arquivo: str
    tamanho_bytes: Optional[int] = None
    enviado_em: datetime


class DocumentoProposta(BaseModel):
    """Documento anexado direto numa proposta pelo corretor logado, pelo
    painel — independente do fluxo (mais antigo, por link público) de
    documentos_qualificacao acima. Ver routers/crm.py."""

    id: str
    proposta_id: str
    tipo: DocumentoTipo
    nome_arquivo: str
    tamanho_bytes: Optional[int] = None
    enviado_por: Optional[str] = None
    enviado_em: datetime


class QualificacaoPublica(BaseModel):
    """O que o cliente final vê ao abrir o link — só o necessário pra
    preencher o formulário, nada de dados internos (corretor, ids de
    outros clientes etc.)."""

    status: QualificacaoStatus
    dados: dict = Field(default_factory=dict)
    documentos: list[DocumentoQualificacao] = Field(default_factory=list)
    lote_identificador: str
    condominio_nome: str
    motivo_reprovacao: Optional[str] = None


class QualificacaoDecisao(BaseModel):
    aprovado: bool
    motivo_reprovacao: Optional[str] = None
