-- Mudança de arquitetura de login: os corretores deixam de ser convidados
-- por e-mail (fluxo antigo em criar_corretor) e passam a ter um login por
-- "usuário" (ex.: italo.nunes), com senha inicial = o próprio telefone (só
-- dígitos). O Supabase Auth continua exigindo um e-mail por baixo de todo
-- usuário — a gente fabrica um (usuario@corretor.login) que a pessoa nunca
-- vê nem usa; ver backend/app/usuarios.py, que é a única fonte de verdade
-- pra esse domínio (front e back têm que combinar).
alter table corretores add column if not exists usuario text unique;

-- Fluxo novo não passa mais pelo Cadastro de Cliente/Qualificação pra saber
-- quem é o interessado: o corretor informa nome + CPF (opcional) direto no
-- pedido de reserva (reservas.nome/contato já existiam; só faltava o CPF).
alter table reservas add column if not exists cpf text;
